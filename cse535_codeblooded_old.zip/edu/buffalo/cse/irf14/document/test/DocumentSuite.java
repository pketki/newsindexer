package edu.buffalo.cse.irf14.document.test;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ParserTest.class})
public class DocumentSuite {

}
