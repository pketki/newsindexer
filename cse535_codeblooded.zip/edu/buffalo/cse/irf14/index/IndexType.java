/**
 * 
 */
package edu.buffalo.cse.irf14.index;

/**
 * @author nikhillo
 *
 */
public enum IndexType {
	TERM, AUTHOR, CATEGORY, PLACE
};
